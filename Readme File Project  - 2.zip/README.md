# 🏠 House Price Prediction — Complete Supervised Learning Project

> **End-to-end Supervised Learning Regression project using Python, Pandas, NumPy, Matplotlib and Scikit-learn.**

![Python](https://img.shields.io/badge/Python-3.10%2B-blue)
![Pandas](https://img.shields.io/badge/Pandas-Data%20Analysis-purple)
![Scikit--learn](https://img.shields.io/badge/Scikit--learn-Machine%20Learning-orange)
![Supervised Learning](https://img.shields.io/badge/ML-Supervised%20Learning-success)
![Status](https://img.shields.io/badge/Project-Completed-brightgreen)

---

## 🎬 Project Results GIF

<p align="center">
  <img src="project_results.gif" alt="House Price Prediction Project Results" width="900">
</p>

> The GIF cycles through the **exact project charts** supplied for this project. No unrelated visualization has been added.

---

# 📌 1. Project Overview

**House Price Prediction** is a **Supervised Learning — Regression** project.

The objective is to predict:

```text
house_price_inr
```

from property-related features.

The complete workflow covers dataset inspection, preprocessing, feature engineering, model training, cross-validation, model evaluation, model comparison, overfitting/underfitting analysis, business interpretation and final model selection.

### 🎯 Problem Type

```text
Machine Learning
      ↓
Supervised Learning
      ↓
Regression
      ↓
House Price Prediction
```

---

# 📊 2. Dataset

The project uses **3,800 records** and **12 original columns**.

| Column | Description |
|---|---|
| `property_id` | Unique property identifier |
| `sale_date` | Property sale date |
| `area_sqft` | Property area in square feet |
| `bedrooms` | Number of bedrooms |
| `bathrooms` | Number of bathrooms |
| `location_score` | Location quality score |
| `property_age` | Property age |
| `distance_city_km` | Distance from city center |
| `near_school` | School proximity indicator |
| `near_metro` | Metro proximity indicator |
| `crime_rate_index` | Local crime-rate index |
| `house_price_inr` | Target house price |

### Target

```python
y = df["house_price_inr"]
```

### Features Used

```text
area_sqft
bedrooms
bathrooms
location_score
property_age
distance_city_km
near_school
near_metro
crime_rate_index
sale_year
sale_month
```

---

# 🔄 3. Complete Machine Learning Workflow

```text
Dataset
   ↓
Data Inspection
   ↓
Missing Value Check
   ↓
Date Conversion
   ↓
Feature Engineering
   ↓
Train-Test Split
   ↓
Feature Scaling
   ↓
Ridge Regression
   ↓
Lasso Regression
   ↓
Alpha Cross-Validation
   ↓
Ridge vs Lasso Comparison
   ↓
K-Fold Cross-Validation
   ↓
Stratified K-Fold
   ↓
Leave-One-Out
   ↓
Time Series Split
   ↓
Decision Tree Regression
   ↓
Tree Complexity Control
   ↓
Random Forest Regression
   ↓
SVR Linear
   ↓
SVR RBF
   ↓
SVR Hyperparameter Tuning
   ↓
MSE / MAE / RMSE / R²
   ↓
Model Comparison
   ↓
Overfitting / Underfitting Analysis
   ↓
Business Interpretation
   ↓
Final Model Selection
```

---

# ✅ 4. Complete Task List

| Task | Work Completed | Status |
|---|---|---|
| 1–8 | Dataset, preprocessing, feature engineering, split and scaling | ✅ Done |
| 9 | Ridge Regression | ✅ Done |
| 10 | Lasso Regression | ✅ Done |
| 11 | Alpha Cross-Validation | ✅ Done |
| 12 | Ridge vs Lasso Comparison | ✅ Done |
| 13 | K-Fold, Stratified K-Fold, Leave-One-Out, Time Series Split | ✅ Done |
| 14 | Cross-Validation Metrics Analysis | ✅ Done |
| 15 | Decision Tree Regression | ✅ Done |
| 16 | Tree Complexity Control | ✅ Done |
| 17 | Random Forest Regression | ✅ Done |
| 18 | Tree vs Ensemble Comparison | ✅ Done |
| 19 | SVR Linear and RBF Kernels | ✅ Done |
| 20 | SVR Hyperparameter Tuning | ✅ Done |
| 21 | SVR Performance Comparison | ✅ Done |
| 22 | MSE, MAE, RMSE and R² Evaluation | ✅ Done |
| 23 | Complete Model Comparison | ✅ Done |
| 24 | Overfitting / Underfitting Analysis | ✅ Done |
| 25 | Final Analysis and Report | ✅ Done |
| 26 | Evaluation Tables and Final Charts | ✅ Done |

---

# 🤖 5. Models Included

The project evaluates all seven requested models:

1. **Ridge Regression**
2. **Lasso Regression**
3. **Decision Tree Regression**
4. **Random Forest Regression**
5. **SVR Linear**
6. **SVR RBF**
7. **SVR Tuned**

---

## 5.1 Ridge Regression

Ridge uses **L2 regularization** to control coefficient magnitude and reduce model complexity.

```python
Ridge(alpha=1.0)
```

Best alpha:

```text
1.151395
```

---

## 5.2 Lasso Regression

Lasso uses **L1 regularization** and can shrink coefficients toward zero.

```python
Lasso(alpha=1.0, max_iter=100000)
```

Best alpha:

```text
1000.0
```

---

## 5.3 Decision Tree Regression

The unrestricted tree produced:

```text
Training RMSE = 0
Testing RMSE  ≈ 3.290 Million INR
Testing R²    ≈ 0.866
```

A controlled tree was also evaluated with:

```text
max_depth = 5
min_samples_split = 10
min_samples_leaf = 5
```

---

## 5.4 Random Forest Regression

Configuration:

```text
Number of Trees = 100
random_state = 42
```

Final test performance:

```text
RMSE ≈ 2.405 Million INR
MAE  ≈ 1.758 Million INR
R²   ≈ 0.928
```

---

## 5.5 Support Vector Regression

The project evaluates:

- Linear SVR
- RBF SVR
- Tuned SVR using `GridSearchCV`

---

# 🔬 6. Cross-Validation

Four cross-validation strategies were evaluated.

### K-Fold

```text
RMSE ≈ 2.495 Million
MAE  ≈ 1.907 Million
R²   ≈ 0.916
```

### Stratified K-Fold

```text
RMSE ≈ 2.491 Million
MAE  ≈ 1.905 Million
R²   ≈ 0.917
```

### Leave-One-Out

```text
RMSE ≈ 1.881 Million
MAE  ≈ 1.881 Million
R²   = NaN
```

### Time Series Split

```text
RMSE ≈ 2.518 Million
MAE  ≈ 1.922 Million
R²   ≈ 0.916
```

### Cross-Validation Summary

```text
Best RMSE Strategy → Leave-One-Out
Best MAE Strategy  → Leave-One-Out
Best R² Strategy   → Stratified K-Fold
```

---

# 📏 7. Evaluation Metrics

| Metric | Meaning | Better Value |
|---|---|---|
| **MSE** | Mean Squared Error | Lower |
| **RMSE** | Root Mean Squared Error | Lower |
| **MAE** | Mean Absolute Error | Lower |
| **R²** | Coefficient of Determination | Higher |

---

# 🏆 8. Complete Model Performance

| Rank | Model | MSE | MAE | RMSE | R² |
|---:|---|---:|---:|---:|---:|
| 🥇 1 | **Random Forest** | 5.786e12 | 1,757,755 | **2,405,402** | **0.928156** |
| 🥈 2 | **Lasso** | 6.451e12 | 1,945,576 | 2,539,903 | 0.919897 |
| 🥉 3 | **Ridge** | 6.452e12 | 1,945,365 | 2,539,990 | 0.919892 |
| 4 | Decision Tree | 1.083e13 | 2,395,188 | 3,290,412 | 0.865564 |
| 5 | SVR Linear | 7.261e13 | 6,620,502 | 8,521,443 | 0.098344 |
| 6 | SVR RBF | 8.059e13 | 6,985,495 | 8,976,954 | -0.000627 |
| 7 | SVR Tuned | 8.059e13 | 6,985,495 | 8,976,954 | -0.000627 |

---

# 🥇 9. Final Best Model — Random Forest

```text
Best Model : Random Forest

MSE  : 5,785,958,403,336.219
MAE  : 1,757,755.0068
RMSE : 2,405,401.9214
R²   : 0.9281561279
```

### Why Random Forest?

- Lowest test RMSE.
- Lowest test MAE.
- Highest test R².
- Captures non-linear relationships.
- Performs better than the individual Decision Tree.
- Provides feature-importance information.

### Final Decision

```text
Best Regularized Linear Model → Lasso
Best Overall Model             → Random Forest
```

---

# 🌳 10. Random Forest Feature Importance

| Feature | Importance |
|---|---:|
| `area_sqft` | 0.741882 |
| `location_score` | 0.205897 |
| `property_age` | 0.012402 |
| `distance_city_km` | 0.009570 |
| `crime_rate_index` | 0.008908 |
| `sale_year` | 0.006553 |
| `sale_month` | 0.005761 |
| `bedrooms` | 0.003207 |
| `bathrooms` | 0.003183 |
| `near_metro` | 0.001447 |
| `near_school` | 0.001191 |

> **Key observation:** `area_sqft` is the most important reported feature, followed by `location_score`.

---

# 📈 11. Exact Project Charts

This section combines the **exact-chart documentation** from the second supplied file with the detailed project README.

## Figure 1 — Ridge vs Lasso Feature Coefficients

This chart compares the feature coefficients produced by Ridge and Lasso regression.

<p align="center">
  <img src="Figure_1_Ridge_vs_Lasso_Coefficients.png" alt="Ridge vs Lasso Feature Coefficients" width="900">
</p>

## Figure 1 — Ridge vs Lasso Error Comparison

This chart compares training, validation and test RMSE for Ridge and Lasso.

<p align="center">
  <img src="Figure_1_Ridge_vs_Lasso_Error.png" alt="Ridge vs Lasso Error Comparison" width="900">
</p>

## Figure 2 — Model RMSE Comparison

Lower RMSE represents lower prediction error.

<p align="center">
  <img src="Figure_2_Model_RMSE.png" alt="Model RMSE Comparison" width="900">
</p>

## Figure 2 — Model R² Comparison

Higher R² indicates stronger explanatory performance on the evaluation data.

<p align="center">
  <img src="Figure_2_Model_R2.png" alt="Model R2 Comparison" width="900">
</p>

## Figure 2 — Model MAE Comparison

Lower MAE indicates a lower average absolute prediction error.

<p align="center">
  <img src="Figure_2_Model_MAE.png" alt="Model MAE Comparison" width="900">
</p>

> **Visualization policy:** Only the supplied/existing project charts are included. No unrelated chart has been added.

---

# 🔍 12. Overfitting / Underfitting Analysis

| Model | Train R² | Test R² | R² Gap | Status |
|---|---:|---:|---:|---|
| Ridge | 0.917402 | 0.919892 | -0.002490 | Good Fit |
| Lasso | 0.917402 | 0.919897 | -0.002495 | Good Fit |
| Decision Tree | 1.000000 | 0.865564 | 0.134436 | Good Fit |
| Random Forest | 0.989346 | 0.928156 | 0.061190 | Good Fit |
| SVR Linear | 0.097443 | 0.098344 | -0.000902 | Underfitting |
| SVR RBF | -0.004414 | -0.000627 | -0.003787 | Underfitting |
| SVR Tuned | -0.004414 | -0.000627 | -0.003787 | Underfitting |

### Interpretation

- Decision Tree reaches perfect training R² but has a substantially lower test R².
- Random Forest has a smaller generalization gap than the unrestricted Decision Tree.
- Ridge and Lasso show very similar train/test R².
- SVR Linear and SVR RBF show weak predictive performance for this dataset.

---

# 🧠 13. SVR Results

### SVR Linear

```text
MAE  ≈ 6,620,502
RMSE ≈ 8,521,443
R²   ≈ 0.098344
```

### SVR RBF

```text
MAE  ≈ 6,985,495
RMSE ≈ 8,976,954
R²   ≈ -0.000627
```

### Tuned SVR

```python
{
    "C": 100,
    "epsilon": 0.1,
    "gamma": "scale"
}
```

The tuned SVR produced the same reported performance as the RBF model.

---

# 💼 14. Business Interpretation

A house-price prediction model can support:

1. Property price estimation.
2. Property comparison.
3. Data-driven pricing decisions.
4. Identification of important price-driving features.
5. Reduction of manual estimation effort.
6. Property valuation analysis.

> The model should be considered a **decision-support system**, not a replacement for professional property valuation.

---

# 🛠️ 15. Technologies Used

| Technology | Purpose |
|---|---|
| Python | Programming |
| Pandas | Data manipulation |
| NumPy | Numerical computation |
| Matplotlib | Visualization |
| Scikit-learn | Machine Learning |
| Jupyter Notebook | Development and experimentation |

---

# 📦 16. Main Python Libraries

```python
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

from sklearn.model_selection import (
    train_test_split,
    KFold,
    StratifiedKFold,
    LeaveOneOut,
    TimeSeriesSplit,
    GridSearchCV,
    cross_val_score
)

from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import Ridge, Lasso
from sklearn.tree import DecisionTreeRegressor
from sklearn.ensemble import RandomForestRegressor
from sklearn.svm import SVR

from sklearn.metrics import (
    mean_squared_error,
    mean_absolute_error,
    r2_score
)
```

---

# ▶️ 17. How to Run

### Install dependencies

```bash
pip install numpy pandas matplotlib scikit-learn jupyter
```

### Start Jupyter

```bash
jupyter notebook
```

### Open

```text
House_Price_Regression_Complete.ipynb
```

### Dataset

```text
House_Price_Dataset.csv
```

Run all notebook cells from top to bottom to reproduce the project.

---

# 📂 18. Recommended GitHub Structure

```text
House_Price_Prediction/
│
├── House_Price_Dataset.csv
├── House_Price_Regression_Complete.ipynb
├── house_price_regression.py
├── requirements.txt
├── README.md
├── project_results.gif
│
├── Figure_1_Ridge_vs_Lasso_Coefficients.png
├── Figure_1_Ridge_vs_Lasso_Error.png
├── Figure_2_Model_RMSE.png
├── Figure_2_Model_R2.png
├── Figure_2_Model_MAE.png
│
├── Part_H_Final_Model_Comparison.csv
├── Part_H_Overfitting_Analysis.csv
└── Part_H_Final_Report.txt
```

---

# 🎓 19. Skills Demonstrated

### Python
- Data loading
- Functions
- NumPy
- Pandas
- File handling

### Data Preprocessing
- Data-type inspection
- Missing-value checking
- Date conversion
- Feature engineering
- Train-test splitting
- Standard scaling

### Supervised Machine Learning
- Regression
- Ridge
- Lasso
- Decision Tree
- Random Forest
- Support Vector Regression

### Model Validation
- K-Fold
- Stratified K-Fold
- Leave-One-Out
- Time Series Split
- GridSearchCV

### Model Evaluation
- MSE
- RMSE
- MAE
- R²
- Model comparison
- Overfitting analysis
- Underfitting analysis

---

# 🎤 20. Interview Explanation

> **“I developed an end-to-end supervised learning regression project for house price prediction using Python and Scikit-learn. I performed data inspection, date feature engineering, train-test splitting and feature scaling. I implemented Ridge and Lasso regression, compared their regularization performance, evaluated multiple cross-validation strategies, built Decision Tree and Random Forest models, implemented Linear and RBF SVR with hyperparameter tuning, and compared all models using MSE, MAE, RMSE and R². Random Forest achieved the best overall test performance with an R² of approximately 0.928 and an RMSE of approximately 2.405 million INR.”**

---

# ⭐ 21. Final Conclusion

```text
Project Type:
Supervised Learning → Regression

Dataset:
3,800 records

Models:
7 evaluated models

Best Overall Model:
Random Forest

Best Test RMSE:
≈ 2.405 Million INR

Best Test MAE:
≈ 1.758 Million INR

Best Test R²:
≈ 0.928
```

### Final Model Ranking

```text
1. Random Forest  → R² 0.928156
2. Lasso          → R² 0.919897
3. Ridge          → R² 0.919892
4. Decision Tree  → R² 0.865564
5. SVR Linear     → R² 0.098344
6. SVR RBF        → R² -0.000627
7. SVR Tuned      → R² -0.000627
```

---

# 📜 License

This project is created for **educational, academic, portfolio and demonstration purposes**.

---

# 👨‍💻 Author

**Your Name**

**BCA | Data Science | Python | Machine Learning**

---

## ⭐ Project Highlights

```text
🏠 House Price Prediction
🤖 Supervised Learning
📊 Regression
🐍 Python
📚 Scikit-learn
🌲 Random Forest
📈 RMSE / MAE / R²
🔬 Cross-Validation
🎯 Model Selection
🎬 Project Results GIF
💼 Portfolio Ready
```

> **Built as a complete supervised-learning project — from property data to model evaluation and final model selection.**
